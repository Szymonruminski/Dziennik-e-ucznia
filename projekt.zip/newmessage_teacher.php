<?php 
error_reporting(E_ALL ^ E_NOTICE);


session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}

  

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">

	<title>Komunikaty</title>
</head>
<body>

    <?php 
    echo "<div class='container2'>";
    echo "<div id='menu'>";
    echo "<a href='teacher.php' title='Strona główna'>Strona główna</a>";
    echo "<a href='students_teacher.php' title='Uczniowie'>Uczniowie</a>";
    echo "<a href='grades_teacher.php' title='Oceny'>Oceny</a>";
    echo "<a href='plan_teacher.php' title='Plan lekcji'>Plan lekcji</a>";
    echo "<a href='frequency_teacher.php' title='Frekwencja'>Frekwencja</a>";
    echo "<a href='messages_teacher.php' title='Komunikaty' class='active'>Komunikaty</a>";
    echo "</div>";
    
    echo "<br><br>";
	include 'config.php';
 
?>

<?php 
include 'config.php';
if(isset($_POST['submitt'])){
    $id_rodzica =$_POST['names'];
    $mess_t =$_POST['mess'];
	$today = date("Y-m-d");
	$zmienna = $_SESSION['username'];
	$zapytanie = "SELECT nazwisko_t from teachers where username = '$zmienna'"; //
	$wynik = mysqli_query($db, $zapytanie);
	$nazwisko_naucz = $wynik->fetch_array()[0] ?? '';
	$zapytanie2 = "SELECT id_nauczyciela from teachers where username = '$zmienna'"; //
	$wynik2 = mysqli_query($db, $zapytanie2);
	$id_naucz = $wynik2->fetch_array()[0] ?? '';
	$zapytanie3 = "SELECT nazwisko from users where id_rodzica = '$id_rodzica'"; //
	$wynik3 = mysqli_query($db, $zapytanie3);
	$nazw_rodz = $wynik3->fetch_array()[0] ?? '';
	
	

 $sql = "INSERT INTO `messages` (`id_wiadomosci`, `id_rodzica`, `nazwisko_r`, `id_nauczyciela`, `nazwisko_t`, `wiadomosc_t`, `wiadomosc_r`, `data_wyslania`) VALUES (NULL, '$id_rodzica','$nazw_rodz' ,'$id_naucz', '$nazwisko_naucz', '$mess_t', '', '$today')";
 $result = mysqli_query($db, $sql);
$myfile = fopen("log.txt", "a") or die("Unable to open file!");
					$txt = "-----Log odnośnie strony do wysyłania wiadomości dla nauzyciela-----\n";
					fwrite($myfile, $txt);
					 $today = date("Y-m-d H:i");
					$txt = $today . " Nuczyciel: " . $_SESSION['username'] . " Wysłał wiadomość do rodzica o ID: " . $id_rodzica . "\n"; 
					fwrite($myfile, $txt);
					fclose($myfile);

 
}

echo "<div id='menu2'>";
    echo "<a href='messages_teacher.php' title='Wiadomosci'>Wiadomości</a>";
    echo "<a href='newmessage_teacher.php' title='Napisz wiadomość' class='active'>Napisz wiadomość</a>";
echo "</div>";
echo "<br><br>";

?>
<div id="frekall"><p><h2>Nowa wiadomość: </h2></p>
<p> Wybierz rodzica do którego chcesz napisać: </p>
    
<form action="" method="POST" id="form1">
     <select name="names">
	

	<?php

  echo "<br>";
 $sql = "SELECT username,id_rodzica,nazwisko from users";
  $result = $db->query($sql);

if ($result->num_rows > 0) {
  // wyświetla dane 
	
  while($row = $result->fetch_assoc()) {

echo "<option value='".$row['id_rodzica']."'>".$row['username']." ".$row['nazwisko']."</option>"; 
  } 

} 

?>
   </select><br><br>
    <p> Treść wiadomości</p>
<textarea name="mess" style="width: 500px" 	required  placeholder='Tutaj wpisz treść wiadomości' rows="4"></textarea>
<br><br>
<button name="submitt" class="button-34" form="form1">Wyślij wiadomość</button>  
<br><br>
  
</form>
<br>
<table class="blueTablemes"> <?php 
if(isset($_POST['submit'])){
$today = date("Y-m-d");
    $id_rodzicaa =$_POST['namess'];
 $zmienna = $_SESSION['username'];
 $zapytaniex = "SELECT username from users where id_rodzica = '$id_rodzicaa'"; 
	$wynikx = mysqli_query($db, $zapytaniex);
	$imie_rodzicaa = $wynikx->fetch_array()[0] ?? '';
	 $zapytaniex2 = "SELECT id_nauczyciela from teachers where user = '$id_rodzicaa'"; 
	$wynikx = mysqli_query($db, $zapytaniex);
	$imie_rodzicaa = $wynikx->fetch_array()[0] ?? '';
$sql = "SELECT `wiadomosc_r`,`wiadomosc_t` FROM `messages` WHERE id_rodzica = '$id_rodzicaa' and id_nauczyciela = (SELECT id_nauczyciela from teachers where username = '$zmienna')  "; //";
 $result = $db->query($sql);

}

if(!empty($imie_rodzicaa))
{
echo "
<thead>
<tr>
<th>Ja(" . $_SESSION['username'] . ")</th>
<th>Rodzic($imie_rodzicaa)</th>
</tr>";
}

if ($result->num_rows > 0) {

  while($row = $result->fetch_assoc()) {  
echo "<tbody><tr><td>"."<h2>" . $row['wiadomosc_t']  ."</h2>". "</td>  <td>" . "<h2>". $row['wiadomosc_r'] . "</h2>" . "</td>  </tr></tbody>";   
}}


echo "</table>";

echo "<br><br><br>";
echo "<div id='stopka'>";

?>
<form action="logout.php">
    <input type="submit"  class="button-34" value="wyloguj" />
</form>
<?php
echo "</div>";
echo "</div>";

	?>

</body>
</html>