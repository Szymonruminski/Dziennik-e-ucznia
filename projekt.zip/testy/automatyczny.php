<?php
use PHPUnit\Framework\TestCase;





class logowanie extends TestCase
{
    public function testlog()
    {
	include 'config.php';

// tesotwanie do utworzenia konta rodzica
		 $sql = "INSERT INTO `students` (`id_ucznia`, `imie`, `nazwisko`, `pesel`) VALUES ('100', 'test_uczen_imie', 'test_uczen_nazwisko', '11111111111')";
	 
				$result = mysqli_query($db, $sql);
				
$imie = 'test_uczen_imie';
$nazwisko ='test_uczen_nazwisko';
$login = 'nauczyciel';
$password ='nauczyciel';
$ocena = '4';
$obecny = 'obecny';
$today = date("Y-m-d");
		$zapytaniex2 = "SELECT imie from students where imie = 'test_uczen_imie'";
	    $wynikx = mysqli_query($db, $zapytaniex2);
		$imie_uczen = $wynikx->fetch_array()[0] ?? '';
		$zapytaniex3 = "SELECT nazwisko from students where nazwisko = 'test_uczen_nazwisko'";
		$wynikx3 = mysqli_query($db, $zapytaniex3);
	    $nazwisko_uczen = $wynikx3->fetch_array()[0] ?? '';
	 
			$this->assertEquals($imie,$imie_uczen);
			$this->assertEquals($nazwisko,$nazwisko_uczen);
				$sql = "INSERT INTO users (username, nazwisko, email, password, pesel)
						VALUES ('test_rodzic_imie','test_rodzic_nazwisko', 'test_rodzic_email@email.com', '207023ccb44feb4d7dadca005ce29a64', '11111111111')";
	 
				$result = mysqli_query($db, $sql);
				
			$zapytanieb = "SELECT login from teachers where login = 'nauczyciel'";
	    $wynikb = mysqli_query($db, $zapytanieb);
	    $login_naucz = $wynikb->fetch_array()[0] ?? '';
	    $zapytaniez = "SELECT login from teachers where login = 'nauczyciel'";
	    $wynikz = mysqli_query($db, $zapytaniez);
	    $password_naucz = $wynikz->fetch_array()[0] ?? '';
	 
			$this->assertEquals($login,$login_naucz);
			$this->assertEquals($password,$password_naucz);		
				
					$sql = "INSERT INTO `grades` (`id_oceny`, `przedmiot`, `ocena`, `id_ucznia`) VALUES (NULL, 'matematyka', '4', '100')";
			$result = mysqli_query($db, $sql);



			$zapytanieoc = "SELECT ocena from grades where id_ucznia = '100' ";
			$wynikoc = mysqli_query($db, $zapytanieoc);
			$ocenadb = $wynikoc->fetch_array()[0] ?? '';
	 
			$this->assertEquals($ocena,$ocenadb);
			
				
		 
  $sql = "INSERT INTO `frekwencja` (`id_obecności`, `nazwisko`, `data`, `przedmiot`, `obecność`) VALUES (NULL, 'test_uczen_nazwisko', '$today','matematyka', 'obecny')";
  		$result = mysqli_query($db, $sql);



		
	    $zapytanieob = "SELECT obecność from frekwencja where nazwisko = 'test_uczen_nazwisko'";
	    $wynikob = mysqli_query($db, $zapytanieob);
	    $obecnydb = $wynikob->fetch_array()[0] ?? '';
	 
			$this->assertEquals($obecny,$obecnydb);
	
    }
}
?>


	
    