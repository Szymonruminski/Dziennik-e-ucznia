<?php
use PHPUnit\Framework\TestCase;





class logowanie extends TestCase
{
    public function testlog()
    {
	include 'config.php';

// tesotwanie do utworzenia konta rodzica
	$sql = "INSERT INTO users (username, nazwisko, email, password, pesel)
						VALUES ('test_rodzic_imie','test_rodzic_nazwisko', 'test_rodzic_email@email.com', '207023ccb44feb4d7dadca005ce29a64', '11111111111')";
	 
				$result = mysqli_query($db, $sql);
				
$email = 'test_rodzic_email@email.com';
$password ='207023ccb44feb4d7dadca005ce29a64';
		$zapytaniex2 = "SELECT email from users where email = 'test_rodzic_email@email.com'";
	    $wynikx = mysqli_query($db, $zapytaniex2);
		$email_rodzic = $wynikx->fetch_array()[0] ?? '';
		$zapytaniex3 = "SELECT password from users where password = '207023ccb44feb4d7dadca005ce29a64'";
		$wynikx3 = mysqli_query($db, $zapytaniex3);
	    $password_rodzic = $wynikx3->fetch_array()[0] ?? '';
	 
			$this->assertEquals($email,$email_rodzic);
			$this->assertEquals($password,$password_rodzic);
				
				
				
    }
}
?>