<?php
use PHPUnit\Framework\TestCase;





class logowanie extends TestCase
{
    public function testlog()
    {
	include 'config.php';

// tesotwanie do logowania nauczyciela
$login = 'nauczyciel';
$password ='nauczyciel';
		$zapytaniex2 = "SELECT login from teachers where login = 'nauczyciel'";
	    $wynikx = mysqli_query($db, $zapytaniex2);
	    $login_naucz = $wynikx->fetch_array()[0] ?? '';
	    $zapytaniex3 = "SELECT login from teachers where login = 'nauczyciel'";
	    $wynikx3 = mysqli_query($db, $zapytaniex3);
	    $password_naucz = $wynikx3->fetch_array()[0] ?? '';
	 
			$this->assertEquals($login,$login_naucz);
			$this->assertEquals($password,$password_naucz);
    }
}
?>