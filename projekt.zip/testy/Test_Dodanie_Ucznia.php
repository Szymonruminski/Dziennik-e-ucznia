<?php
use PHPUnit\Framework\TestCase;





class logowanie extends TestCase
{
    public function testlog()
    {
	include 'config.php';

// tesotwanie do utworzenia konta rodzica
		 $sql = "INSERT INTO `students` (`id_ucznia`, `imie`, `nazwisko`, `pesel`) VALUES (100, 'test_uczen_imie', 'test_uczen_nazwisko', '11111111111')";
	 
				$result = mysqli_query($db, $sql);
				
$imie = 'test_uczen_imie';
$nazwisko ='test_uczen_nazwisko';
		$zapytaniex2 = "SELECT imie from students where imie = 'test_uczen_imie'";
	    $wynikx = mysqli_query($db, $zapytaniex2);
		$imie_uczen = $wynikx->fetch_array()[0] ?? '';
		$zapytaniex3 = "SELECT nazwisko from students where nazwisko = 'test_uczen_nazwisko'";
		$wynikx3 = mysqli_query($db, $zapytaniex3);
	    $nazwisko_uczen = $wynikx3->fetch_array()[0] ?? '';
	 
			$this->assertEquals($imie,$imie_uczen);
			$this->assertEquals($nazwisko,$nazwisko_uczen);
				
				
				
    }
}
?>