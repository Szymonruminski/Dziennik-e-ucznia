<?php
use PHPUnit\Framework\TestCase;





class logowanie extends TestCase
{
    public function testlog()
    {
		include 'config.php';

			$sql = "INSERT INTO `grades` (`id_oceny`, `przedmiot`, `ocena`, `id_ucznia`) VALUES (NULL, 'matematyka', '4', '100')";
			$result = mysqli_query($db, $sql);


				// sprawdzenie ocen
			$ocena = '4';

	
			$zapytaniex3 = "SELECT ocena from grades where id_ucznia = '100' ";
			$wynikx3 = mysqli_query($db, $zapytaniex3);
			$ocenadb = $wynikx3->fetch_array()[0] ?? '';
	 
			$this->assertEquals($ocena,$ocenadb);
	
    }
}
?>