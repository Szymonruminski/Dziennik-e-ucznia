<?php
use PHPUnit\Framework\TestCase;





class logowanie extends TestCase
{
    public function testlog()
    {
	include 'config.php';
    $today = date("Y-m-d");
  $sql = "INSERT INTO `frekwencja` (`id_obecności`, `nazwisko`, `data`, `przedmiot`, `obecność`) VALUES (NULL, 'test_uczen_nazwisko', '$today','matematyka', 'obecny')";
  		$result = mysqli_query($db, $sql);
// tesotwanie do logowania nauczyciela
$obecny = 'obecny';

		
	    $zapytanieob = "SELECT obecność from frekwencja where nazwisko = 'test_uczen_nazwisko'";
	    $wynikob = mysqli_query($db, $zapytanieob);
	    $obecnydb = $wynikob->fetch_array()[0] ?? '';
	 
			$this->assertEquals($obecny,$obecnydb);
	
    }
}
?>